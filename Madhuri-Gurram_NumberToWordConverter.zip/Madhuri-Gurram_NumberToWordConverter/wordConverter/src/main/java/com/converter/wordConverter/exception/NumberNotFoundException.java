package com.converter.wordConverter.exception;

public class NumberNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NumberNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NumberNotFoundException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public NumberNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public NumberNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public NumberNotFoundException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
